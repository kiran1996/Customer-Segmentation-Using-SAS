library(dplyr)
library(tidyverse)

setwd("C:/Users/naiki/OneDrive - LA TROBE UNIVERSITY/Desktop/Trushal/CA - Assignment - 2/Parth")
Behavior <- read.csv("Behavioural.csv")
Demograph <- read.csv("Demographics.csv")

freq_table <- table(Demograph$X_SEGMENT_, Behavior$X_SEGMENT_)
freq_table
options(scipen = 999, digits = 3)
prop.table(table(Demograph$X_SEGMENT_,Behavior$X_SEGMENT_))


yes_table <- table(Demograph$X_SEGMENT_, Behavior$X_SEGMENT_, Demograph$Subscribed)
yes_table <- yes_table[,,2]
yes_table / freq_table
